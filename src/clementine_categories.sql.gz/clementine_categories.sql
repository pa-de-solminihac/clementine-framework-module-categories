-- MySQL dump 10.13  Distrib 5.1.37, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: quai13v5
-- ------------------------------------------------------
-- Server version	5.1.37-1ubuntu5.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clementine_categories`
--

DROP TABLE IF EXISTS `clementine_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clementine_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_parent` int(11) NOT NULL DEFAULT 0,
  `nom` varchar(128) DEFAULT NULL,
  `date_modification` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_creation` timestamp NOT NULL,
  `rang_tri` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clementine_categories`
--

INSERT INTO `clementine_categories` VALUES 
    (43,0,'QUOI DE NEUF ?','2008-11-13 18:39:47','2008-11-13 18:39:47',0,1),
    (2,0,'D&Eacute;CO','2008-10-25 02:11:50','2008-10-25 02:11:50',1,1),
    (3,0,'INFORMATIQUE','2008-10-25 02:11:50','2008-10-25 02:11:50',4,1),
    (4,0,'&Eacute;LECTROM&Eacute;NAGER','2008-10-25 02:11:50','2008-10-25 02:11:50',2,1),
    (5,0,'IMAGE-SON-T&Eacute;L&Eacute;PHONE','2008-10-25 02:11:50','2008-10-25 02:11:50',3,1),
    (6,2,'INT&Eacute;RIEUR','2008-10-25 02:11:50','2008-10-25 02:11:50',0,1),
    (7,2,'EXT&Eacute;RIEUR','2008-10-25 02:11:50','2008-10-25 02:11:50',0,1),
    (24,4,'LAVAGE','2008-11-09 21:22:17','2008-11-09 21:22:17',1,1),
    (23,4,'FROID','2008-11-09 21:22:07','2008-11-09 21:22:07',0,1),
    (10,6,'s&#039;assoir','2008-10-25 02:11:50','2008-10-25 02:11:50',0,1),
    (68,6,'accessoires','2008-12-18 22:04:06','2008-12-18 22:04:06',2,1),
    (65,31,'accessoires','2008-12-18 14:40:23','2008-12-18 14:40:23',0,1),
    (62,6,'s&#039;&eacute;clairer','2008-12-15 19:27:19','2008-12-15 19:27:19',1,1),
    (15,3,'ORDINATEURS','2008-10-26 10:13:48','2008-10-26 10:13:48',0,1),
    (16,15,'PORTABLE','2008-10-26 10:14:11','2008-10-26 10:14:11',0,1),
    (18,0,'TRANSPORT &Eacute;LECTRIQUE','2008-10-31 18:24:22','2008-10-31 18:24:22',5,1),
    (19,0,'G&Eacute;NIAL !','2008-10-31 18:24:31','2008-10-31 18:24:31',6,1),
    (25,4,'CUISSON','2008-11-09 21:22:24','2008-11-09 21:22:24',2,1),
    (26,4,'PETIT &Eacute;LEC','2008-11-09 21:22:47','2008-11-09 21:22:47',3,1),
    (27,5,'REGARDER','2008-11-09 21:24:13','2008-11-09 21:24:13',0,1),
    (28,5,'CAPTURER','2008-11-09 21:24:24','2008-11-09 21:24:24',1,1),
    (29,5,'T&Eacute;L&Eacute;PHONER','2008-11-09 21:24:44','2008-11-09 21:24:44',2,1),
    (30,5,'&Eacute;COUTER','2008-11-09 21:24:53','2008-11-09 21:24:53',3,1),
    (31,3,'P&Eacute;RIPH&Eacute;RIQUES','2008-11-09 21:29:52','2008-11-09 21:29:52',1,1),
    (32,18,'2 ROUES','2008-11-09 21:30:17','2008-11-09 21:30:17',0,1),
    (33,18,'4 ROUES','2008-11-09 21:30:24','2008-11-09 21:30:24',1,1),
    (34,30,'baladeurs','2008-11-09 21:31:24','2008-11-09 21:31:24',0,1),
    (35,30,'enceintes multim&eacute;dia','2008-11-09 21:31:40','2008-11-09 21:31:40',1,1),
    (36,30,'enceintes hi-fi','2008-11-09 21:31:58','2008-11-09 21:31:58',2,1),
    (37,29,'portables','2008-11-09 21:32:15','2008-11-09 21:32:15',0,1),
    (38,29,'maison','2008-11-09 21:32:31','2008-11-09 21:32:31',1,1),
    (39,23,'r&eacute;frig&eacute;rateur','2008-11-09 21:33:22','2008-11-09 21:33:22',0,1),
    (40,23,'cave &agrave; vin','2008-11-09 21:33:38','2008-11-09 21:33:38',1,1),
    (66,31,'stockage','2008-12-18 14:40:31','2008-12-18 14:40:31',1,1),
    (52,24,'Lave-linge &amp; vaisselle','2008-12-03 17:18:03','2008-12-03 17:18:03',0,1),
    (42,26,'accessoires','2008-11-10 00:58:02','2008-11-10 00:58:02',0,1),
    (45,15,'&Eacute;CRAN','2008-11-13 18:43:35','2008-11-13 18:43:35',2,1),
    (44,15,'BUREAU','2008-11-13 18:43:08','2008-11-13 18:43:08',1,1),
    (46,27,'lecteur - baladeur','2008-11-15 13:14:12','2008-11-15 13:14:12',0,1),
    (47,7,'s&#039;&eacute;clairer','2008-11-15 15:15:21','2008-11-15 15:15:21',0,1),
    (48,43,'QUOI DE NEUF ?','2008-11-27 19:25:33','2008-11-27 19:25:33',0,1),
    (49,48,'QUOI DE NEUF ?','2008-11-27 19:25:38','2008-11-27 19:25:38',0,1),
    (50,25,'fours &amp; cuisini&egrave;res','2008-12-02 13:50:59','2008-12-02 13:50:59',0,1),
    (51,30,'cha&icirc;nes hi-fi','2008-12-02 17:11:12','2008-12-02 17:11:12',3,1),
    (67,31,'enceintes multimedia','2008-12-18 14:40:46','2008-12-18 14:40:46',2,1),
    (54,26,'aspirateurs','2008-12-04 14:02:24','2008-12-04 14:02:24',1,1),
    (55,26,'beaut&eacute; - bien &ecirc;tre','2008-12-04 14:36:00','2008-12-04 14:36:00',2,1),
    (56,26,'petit-d&eacute;jeuner','2008-12-04 14:53:24','2008-12-04 14:53:24',3,1),
    (57,28,'camescope','2008-12-09 16:33:28','2008-12-09 16:33:28',0,1),
    (58,28,'APN compact','2008-12-09 16:33:49','2008-12-09 16:33:49',1,1),
    (59,28,'APN Bridge/reflex','2008-12-09 16:35:16','2008-12-09 16:35:16',2,1),
    (60,27,'cadre','2008-12-10 15:07:48','2008-12-10 15:07:48',1,1),
    (61,27,'ecran plat - projecteur','2008-12-10 15:16:50','2008-12-10 15:16:50',2,1),
    (69,6,'se d&eacute;tendre','2008-12-18 22:05:19','2008-12-18 22:05:19',3,1),
    (73,6,'travailler','2008-12-20 17:30:09','2008-12-20 17:30:09',4,1),
    (71,7,'se pr&eacute;lasser','2008-12-18 22:13:44','2008-12-18 22:13:44',2,1),
    (72,7,'accessoires','2008-12-18 22:13:53','2008-12-18 22:13:53',3,1);

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-02-11 18:19:02
